/**
 * @brief Movie class implementation
 * @author George Baker
 * @date 2020/10/08
 *
 */

#include "Movie.h"

Movie::Movie(std::string movie_name_val, std::string movie_rating_val)
    : movie_name {movie_name_val}, movie_rating {movie_rating_val}, watched_count{0} {
    std::cout << "2 arg constructor called" << std::endl;
}

Movie::Movie(std::string movie_name_val) {
    : Movie {movie_name_val,"NR"} {
    std::cout << "1 arg constructor called" << std::endl;
}

Movie::Movie()
    : Movie {"none","NR"} {
    std::cout << "default constructor called" << std::endl;
}

void Movie::increase_watch_count() {
    ++watched_count;
    std::cout << movie_name << " watched " << watched_count << " times." << std::endl;
}

void Movie::reset_watch_count() {
    watched_count = 0;
}


